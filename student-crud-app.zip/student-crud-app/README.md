# Student Record Management System
### Mini Web Application — CRUD-Based Web App (VSB Skill Vault — Activity 3)

A complete CRUD (Create, Read, Update, Delete) web application for managing
student records, built for the VSB Skill Vault Activity 3 assignment.

## Tech Stack

| Layer      | Technology                                   |
|------------|-----------------------------------------------|
| Frontend   | HTML5, CSS3, Vanilla JavaScript (fetch API)   |
| Backend    | Node.js, Express.js                           |
| Database   | JSON file-based persistence (`data/db.json`)  |

## Features

- **Create** — Add a new student record via a form (name, register no.,
  department, CGPA, email).
- **Read** — View all student records in a live-updating table.
- **Update** — Edit any existing record in place.
- **Delete** — Remove a record with a confirmation prompt.
- Clean, responsive UI with instant feedback (no page reloads — all CRUD
  operations happen via `fetch()` calls to a REST API).
- Server-side input validation (name, register no., and department are
  required).

## Project Structure

```
student-crud-app/
├── server.js          # Express server + REST API routes
├── db.js              # Data-access layer (file-based "database")
├── data/
│   └── db.json         # Persisted student records
├── public/
│   ├── index.html       # UI markup
│   ├── style.css        # Styling
│   └── script.js        # Frontend logic (calls the REST API)
├── package.json
└── README.md
```

## REST API Reference

| Method | Endpoint             | Description            |
|--------|-----------------------|-------------------------|
| GET    | `/api/students`       | Get all students        |
| GET    | `/api/students/:id`   | Get one student by ID   |
| POST   | `/api/students`       | Create a new student    |
| PUT    | `/api/students/:id`   | Update a student by ID  |
| DELETE | `/api/students/:id`   | Delete a student by ID  |

## How to Run

1. Make sure [Node.js](https://nodejs.org/) (v16+) is installed.
2. Open a terminal in the project folder.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the server:
   ```
   npm start
   ```
5. Open your browser at:
   ```
   http://localhost:3000
   ```

## How It Works (for the report)

- The **frontend** (`public/`) renders a form and a table. On page load, it
  calls `GET /api/students` and renders the results.
- Submitting the form calls `POST /api/students` (create) or
  `PUT /api/students/:id` (update, when editing an existing row).
- Clicking **Delete** calls `DELETE /api/students/:id` after a confirm
  dialog, then reloads the table.
- The **backend** (`server.js`) exposes these routes with Express and
  delegates all data operations to `db.js`.
- `db.js` acts as the **database layer**: it reads/writes student records
  as JSON in `data/db.json`, exposing `getAll`, `getById`, `create`,
  `update`, and `remove` — the same shape a real SQL/NoSQL driver would
  expose, so it could be swapped for MongoDB/MySQL later without touching
  the routes.

## Possible Extensions

- Swap `db.js` for a real database (MongoDB with Mongoose, or MySQL/SQLite).
- Add search/filter and sorting on the student table.
- Add authentication so only authorized users can edit/delete records.
