/**
 * db.js
 * -----------------------------------------------------------------------
 * Lightweight file-based "database" layer.
 *
 * Instead of pulling in a native database driver (which can be tricky to
 * install on college lab machines), all student records are persisted as
 * JSON in data/db.json. Every function below mirrors what a real database
 * module would expose (getAll, getById, create, update, remove), so the
 * rest of the app (server.js) talks to this file exactly like it would
 * talk to MongoDB/MySQL/SQLite. Swapping this file out for a real DB
 * driver later would not require changing any route code.
 * -----------------------------------------------------------------------
 */

const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "data", "db.json");

function readData() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ students: [], nextId: 1 }, null, 2));
  }
  const raw = fs.readFileSync(DB_FILE, "utf-8");
  return JSON.parse(raw);
}

function writeData(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function getAll() {
  return readData().students;
}

function getById(id) {
  return readData().students.find((s) => s.id === Number(id));
}

function create(student) {
  const data = readData();
  const newStudent = {
    id: data.nextId,
    name: student.name,
    rollNo: student.rollNo,
    department: student.department,
    cgpa: student.cgpa,
    email: student.email,
    createdAt: new Date().toISOString()
  };
  data.students.push(newStudent);
  data.nextId += 1;
  writeData(data);
  return newStudent;
}

function update(id, updates) {
  const data = readData();
  const index = data.students.findIndex((s) => s.id === Number(id));
  if (index === -1) return null;
  data.students[index] = {
    ...data.students[index],
    ...updates,
    id: data.students[index].id // id is immutable
  };
  writeData(data);
  return data.students[index];
}

function remove(id) {
  const data = readData();
  const index = data.students.findIndex((s) => s.id === Number(id));
  if (index === -1) return false;
  data.students.splice(index, 1);
  writeData(data);
  return true;
}

module.exports = { getAll, getById, create, update, remove };
