const API_URL = "/api/students";

const form = document.getElementById("student-form");
const idField = document.getElementById("student-id");
const nameField = document.getElementById("name");
const rollNoField = document.getElementById("rollNo");
const departmentField = document.getElementById("department");
const cgpaField = document.getElementById("cgpa");
const emailField = document.getElementById("email");

const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");

const tableBody = document.getElementById("student-table-body");
const countBadge = document.getElementById("count-badge");
const emptyState = document.getElementById("empty-state");

// ---------- READ: fetch and render all students ----------
async function loadStudents() {
  const res = await fetch(API_URL);
  const students = await res.json();
  renderTable(students);
}

function renderTable(students) {
  tableBody.innerHTML = "";
  countBadge.textContent = `${students.length} record${students.length === 1 ? "" : "s"}`;

  if (students.length === 0) {
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  students.forEach((s, i) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.rollNo)}</td>
      <td>${escapeHtml(s.department)}</td>
      <td>${s.cgpa ?? "-"}</td>
      <td>${escapeHtml(s.email || "-")}</td>
      <td>
        <button class="action-btn edit-btn" data-id="${s.id}">Edit</button>
        <button class="action-btn delete-btn" data-id="${s.id}">Delete</button>
      </td>
    `;
    tableBody.appendChild(row);
  });

  document.querySelectorAll(".edit-btn").forEach((btn) =>
    btn.addEventListener("click", () => startEdit(btn.dataset.id))
  );
  document.querySelectorAll(".delete-btn").forEach((btn) =>
    btn.addEventListener("click", () => deleteStudent(btn.dataset.id))
  );
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// ---------- CREATE / UPDATE (shared form submit) ----------
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    name: nameField.value.trim(),
    rollNo: rollNoField.value.trim(),
    department: departmentField.value.trim(),
    cgpa: cgpaField.value ? Number(cgpaField.value) : null,
    email: emailField.value.trim()
  };

  const id = idField.value;

  if (id) {
    // UPDATE
    await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } else {
    // CREATE
    await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  resetForm();
  loadStudents();
});

// ---------- Populate form for editing ----------
async function startEdit(id) {
  const res = await fetch(`${API_URL}/${id}`);
  if (!res.ok) return;
  const student = await res.json();

  idField.value = student.id;
  nameField.value = student.name;
  rollNoField.value = student.rollNo;
  departmentField.value = student.department;
  cgpaField.value = student.cgpa ?? "";
  emailField.value = student.email ?? "";

  formTitle.textContent = "Edit Student";
  submitBtn.textContent = "Save Changes";
  cancelBtn.classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ---------- DELETE ----------
async function deleteStudent(id) {
  if (!confirm("Delete this student record?")) return;
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  loadStudents();
}

// ---------- Cancel edit ----------
cancelBtn.addEventListener("click", resetForm);

function resetForm() {
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add New Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.classList.add("hidden");
}

// Initial load
loadStudents();
