/**
 * server.js
 * -----------------------------------------------------------------------
 * Mini Web Application - Student Record Management System
 * VSB Skill Vault - Activity 3 (CRUD-Based Web Application)
 *
 * Stack: Node.js + Express (backend) | HTML/CSS/JS (frontend) | JSON file
 * used as the persistence/database layer (see db.js).
 *
 * Exposes a REST API for full CRUD:
 *   GET    /api/students        -> Read all students
 *   GET    /api/students/:id    -> Read one student
 *   POST   /api/students        -> Create a student
 *   PUT    /api/students/:id    -> Update a student
 *   DELETE /api/students/:id    -> Delete a student
 * -----------------------------------------------------------------------
 */

const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- READ (all) ----------
app.get("/api/students", (req, res) => {
  res.json(db.getAll());
});

// ---------- READ (one) ----------
app.get("/api/students/:id", (req, res) => {
  const student = db.getById(req.params.id);
  if (!student) return res.status(404).json({ error: "Student not found" });
  res.json(student);
});

// ---------- CREATE ----------
app.post("/api/students", (req, res) => {
  const { name, rollNo, department, cgpa, email } = req.body;

  if (!name || !rollNo || !department) {
    return res.status(400).json({ error: "name, rollNo, and department are required" });
  }

  const student = db.create({ name, rollNo, department, cgpa, email });
  res.status(201).json(student);
});

// ---------- UPDATE ----------
app.put("/api/students/:id", (req, res) => {
  const updated = db.update(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: "Student not found" });
  res.json(updated);
});

// ---------- DELETE ----------
app.delete("/api/students/:id", (req, res) => {
  const success = db.remove(req.params.id);
  if (!success) return res.status(404).json({ error: "Student not found" });
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`Student CRUD app running at http://localhost:${PORT}`);
});
